# CEH M09-03 — Bilingual SVG diagrams / 雙語 SVG 示意圖

Seven spatial teaching diagrams, each in Traditional Chinese (zh-TW/) and English (en/).
七張空間關係教學圖，每張包含繁體中文與英文版本，共十四個原生 SVG。

1. Four analysis dimensions / 四維攻擊分析
2. One controller, two channels / 同一控制來源、兩個接觸管道
3. Conditional OTP relay / 有前提的驗證碼轉交流程
4. OTP and phishing-resistant authentication / OTP 與抗釣魚驗證
5. Independent verification / 獨立查證
6. Separate evidence questions / 分別核對各層證據
7. CEH concept relationships / CEH 概念關聯

The Northstar scenario is fictional. Arrows express the labeled relationships,
not proof that compromise occurred. Figure 6 does not assert inevitable
progression; Figure 7 is a concept map rather than an attack sequence.
Northstar 是虛構案例；箭頭代表圖中明示的關係，不代表已證實入侵。
圖6不表示事件必然發展，圖7是概念關聯圖，不是攻擊順序。

SVG text remains editable. No scripts, external images, external font files,
or private source material are included. The website embeds allowlist-validated SVG with visible reflowing explanations.
Fixed diagram geometry remains at least 800px wide in a keyboard-scrollable frame
on narrow screens; use the full-size SVG link to zoom. This is not SVG reflow.
SVG 文字可編輯，不含腳本、外部圖片、外部字型檔或私人來源材料。
網站直接內嵌經白名單驗證的 SVG，並保留可換行文字解說。
窄螢幕圖框保留至少800px寬，可鍵盤左右捲動或開啟原圖放大；SVG本身不是重新排版。

Version 1.2.0 / 2026-10-29
