# 合成幾何圖庫

108 張 Train、45 張 Test。來源為原合成教材 Python 參考產物，非 MATLAB 本次執行結果。MATLAB 案例三會自行產生相同規模的獨立圖庫；不要混用不同執行的 manifest 與影像。
